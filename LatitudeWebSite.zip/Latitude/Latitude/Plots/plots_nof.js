// Begin XHTML adjustment
$(document).ready(function(){
	if (jQuery.browser.msie && jQuery.browser.version.substr(0, 2) == "6.") {
		$(".nof-clearfix").each(function (i) {
			$(this).append("<div style='clear:both'/>");
			$(this).removeClass("nof-clearfix");
		});
	}
	if (jQuery.browser.safari){
		$(".nof-lyr>br:first").each(function () {
			$(this).replaceWith("<div style='height:0px'>&nbsp;</div>");
		});
	}
});

// End XHTML adjustment

// Begin Navigation Bars
var ButtonsImageMapping = [];
ButtonsImageMapping["NavigationBar1"] = {
	"NavigationButton1" : { image: "../Latitude_Np_regular.png", rollover: "../Latitude_NRp_regularOver.png", w: 90, h: 57 },
	"NavigationButton2" : { image: "../Plots_Hp_highlighted.png", rollover: "../Plots_HRp_highlightedOver.png", w: 90, h: 57 },
	"NavigationButton3" : { image: "../Max-Temperature_Ns_regular_1.png", rollover: "../Max-Temperature_NRs_regularOver_1.png", w: 120, h: 57 },
	"NavigationButton4" : { image: "../Humidity_Ns_regular_1.png", rollover: "../Humidity_NRs_regularOver_1.png", w: 120, h: 57 },
	"NavigationButton5" : { image: "../Cloudiness_Ns_regular_1.png", rollover: "../Cloudiness_NRs_regularOver_1.png", w: 120, h: 57 },
	"NavigationButton6" : { image: "../Wind-Speed_Ns_regular_1.png", rollover: "../Wind-Speed_NRs_regularOver_1.png", w: 120, h: 57 },
	"NavigationButton7" : { image: "../Comparisons_Np_regular.png", rollover: "../Comparisons_NRp_regularOver.png", w: 90, h: 57 },
	"NavigationButton8" : { image: "../Data_Np_regular.png", rollover: "../Data_NRp_regularOver.png", w: 90, h: 57 }
};

$(document).ready(function(){
	$.fn.nofNavBarOptions({ navBarId: "NavigationBar1", rollover: true, autoClose: true });
	$("#NavigationBar1").nofNavBar({isMain: true, orientation: "horizontal" });
	$("#NavigationBar1 ul").hide();
});


// End Navigation Bars

